CREATE VIEW order_rating_comparison AS
WITH order_ratings AS(
SELECT order_id, driver_id, restaurant_id, (driver_rating+restaurant_rating)/2 AS "Average_Order_Rating"
FROM rating)

SELECT o.order_id, o.driver_id, drv.person_name, drv.Rating AS "Driver Rating", o.restaurant_id, rrv.restaurant_name, rrv.Rating AS "Restaurant_Rating", orra.Average_Order_Rating, 
AVG(orra.Average_Order_Rating) OVER(PARTITION BY o.driver_id) AS "Average Driver's Order's Rating",
AVG(orra.Average_Order_Rating) OVER(PARTITION BY o.restaurant_id) AS "Average Restaurant's Order's Rating"
FROM campus_eats_fall2020.order as o
LEFT JOIN Driver_Rating_View as drv ON o.driver_id = drv.driver_id
LEFT JOIN Restaurant_Rating_View as rrv ON o.restaurant_id = rrv.restaurant_id
LEFT JOIN order_ratings as orra ON o.order_id = orra.order_id
