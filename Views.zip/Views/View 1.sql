CREATE VIEW Driver_Rating_View AS
SELECT d.driver_id,  p.person_name, count(o.driver_id) AS "Order Count", avg(r.driver_rating) AS "Rating"
FROM driver as d

INNER JOIN student AS s 
ON d.student_id = s.student_id

INNER JOIN person as p
ON s.person_id = p.person_id

INNER JOIN campus_eats_fall2020.order as o
ON o.driver_id = d.driver_id

INNER JOIN rating as r
ON r.driver_id = d.driver_id

GROUP BY driver_id;

SELECT * FROM Driver_rating_view