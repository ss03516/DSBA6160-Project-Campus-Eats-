CREATE VIEW Restaurant_Rating_View AS
SELECT r.restaurant_id, r.restaurant_name, g.Driver_Count, count(o.restaurant_id) as "Number of Orders", avg(ra.restaurant_rating) as "Rating"
FROM restaurant as r
INNER JOIN(
SELECT restaurant_id, count(driver_id) as Driver_Count
FROM campus_eats_fall2020.order
GROUP BY restaurant_id
) as g ON r.restaurant_id = g.restaurant_id
INNER JOIN campus_eats_fall2020.order AS o ON o.restaurant_id = g.restaurant_id
LEFT JOIN rating as ra ON r.restaurant_id = ra.restaurant_id
GROUP BY g.restaurant_id;